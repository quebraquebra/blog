This is a patch release to fix the new R-devel warning.

---

## Test environments
* OS X, R 3.3.2
* Ubuntu 14.04, R 3.3.2
* win-builder (devel and release)

## R CMD check results

There were no ERRORs, WARNING or NOTEs

## Reverse dependencies

I did not run R CMD check as this change should not impact any downstream code.
