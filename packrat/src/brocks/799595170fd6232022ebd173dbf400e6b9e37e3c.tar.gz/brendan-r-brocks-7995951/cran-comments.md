## Test environments
* Ubuntu 12.04 (on travis-ci), R 3.1.2
* Windows Server 2012 R2 (x64) (on appveyor)
* Ubuntu 14.10 desktop R 3.2.0
* Windows 7, 3.1.3

## R CMD check results
There were no ERRORs or WARNINGs. 

There was one NOTE:

* checking CRAN incoming feasibility ... NOTE
Maintainer: ‘Brendan Rocks <rocks.brendan@gmail.com>’

License components with restrictions and base license permitting such:
  MIT + file LICENSE
File 'LICENSE':
  YEAR: 2015
  COPYRIGHT HOLDER: Brendan Rocks