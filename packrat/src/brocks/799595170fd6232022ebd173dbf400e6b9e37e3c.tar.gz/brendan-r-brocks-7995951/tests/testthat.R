library(testthat)
library(brocks)

test_check("brocks")
