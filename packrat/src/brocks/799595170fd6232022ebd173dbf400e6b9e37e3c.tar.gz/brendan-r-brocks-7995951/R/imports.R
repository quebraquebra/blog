#' @importFrom magrittr %>%
NULL

# For R CMD Check: https://github.com/tidyverse/magrittr/issues/29
globalVariables(".")
