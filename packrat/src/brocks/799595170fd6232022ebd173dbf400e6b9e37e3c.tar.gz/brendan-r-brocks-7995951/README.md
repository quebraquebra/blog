# brocks
[![Build Status](https://travis-ci.org/brendan-r/brocks.svg)](https://travis-ci.org/brendan-R/brocks)
[![Win Build Status](https://ci.appveyor.com/api/projects/status/github/brendan-r/brocks?branch=master&svg=true)](https://ci.appveyor.com/project/brendan-r/brocks)
[![Project Status: Active - The project has reached a stable, usable state and is being actively developed.](https://img.shields.io/badge/repo%20status-active-brightgreen.svg)](http://www.repostatus.org/#active)
<!--
[![cran version](http://www.r-pkg.org/badges/version/brocks)](http://cran.rstudio.com/web/packages/brocks)
![monthly_downloads](http://cranlogs.r-pkg.org/badges/brocks)
-->

[Brendan's](https://github.com/brendan-r) personal R functions.

## Installation

```R
# install.packages("devtools")
devtools::install_github("brendan-R/brocks")
```
